#include <jni.h>
#include <map>
#include <vector>
#include <string>
#include <sstream>
#include <cstdio>
#include <cctype>

static std::map<std::string, std::string> ini;

static std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}
static bool isnum(const std::string& s) {
    if (s.empty() || s.size() > 9) return false;
    for (char c : s) if (!isdigit((unsigned char)c)) return false;
    return true;
}
static std::string jstr(JNIEnv* e, jstring s) {
    const char* c = e->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    e->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" JNIEXPORT void JNICALL
Java_app_macro_Native_parse(JNIEnv* e, jobject, jstring text) {
    ini.clear();
    std::istringstream in(jstr(e, text));
    std::string line, sec;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line[0] == ';' || line[0] == '#') continue;
        if (line[0] == '[') { size_t p = line.find(']'); if (p != std::string::npos) sec = line.substr(1, p - 1); continue; }
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        ini[sec + "." + trim(line.substr(0, eq))] = trim(line.substr(eq + 1));
    }
}

// Độ nhạy tham khảo: DPI càng cao thì độ nhạy càng giảm
extern "C" JNIEXPORT jint JNICALL
Java_app_macro_Native_sens(JNIEnv*, jobject, jint dpi, jint base) {
    if (dpi <= 0) dpi = 400;
    int v = base * 400 / dpi;
    return v < 1 ? 1 : (v > 100 ? 100 : v);
}

extern "C" JNIEXPORT jint JNICALL
Java_app_macro_Native_repeat(JNIEnv* e, jobject, jstring name) {
    auto it = ini.find(jstr(e, name) + ".repeat");
    if (it == ini.end() || !isnum(it->second)) return 1;
    return std::stoi(it->second);  // 0 = lặp vô hạn
}

// Dựng lệnh shell cho 1 vòng macro. Chỉ nhận số nguyên nên không chèn được lệnh lạ.
extern "C" JNIEXPORT jstring JNICALL
Java_app_macro_Native_script(JNIEnv* e, jobject, jstring name) {
    std::string n = jstr(e, name), out;
    for (int k = 1; k <= 500; k++) {
        auto it = ini.find(n + ".s" + std::to_string(k));
        if (it == ini.end()) break;
        std::istringstream ts(it->second);
        std::vector<std::string> t; std::string w;
        while (ts >> w) t.push_back(w);
        if (t.empty()) continue;
        bool ok = true;
        for (size_t i = 1; i < t.size(); i++) if (!isnum(t[i])) ok = false;
        if (!ok) continue;
        const std::string& c = t[0];
        size_t cnt = t.size() - 1;
        std::string delay;
        if (c == "tap" && cnt >= 2) { out += "input tap " + t[1] + " " + t[2] + ";"; if (cnt >= 3) delay = t[3]; }
        else if (c == "swipe" && cnt >= 5) { out += "input swipe " + t[1] + " " + t[2] + " " + t[3] + " " + t[4] + " " + t[5] + ";"; if (cnt >= 6) delay = t[6]; }
        else if (c == "key" && cnt >= 1) { out += "input keyevent " + t[1] + ";"; if (cnt >= 2) delay = t[2]; }
        else if (c == "wait" && cnt >= 1) { delay = t[1]; }
        if (!delay.empty()) {
            char buf[32]; snprintf(buf, sizeof buf, "sleep %.3f;", std::stod(delay) / 1000.0);
            out += buf;
        }
    }
    return e->NewStringUTF(out.c_str());
}
