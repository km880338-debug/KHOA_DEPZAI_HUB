package app.macro

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var sh: IShell? = null
    @Volatile private var running = false
    private val iniFile by lazy { File(filesDir, "macro.ini") }

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, ShellService::class.java.name))
            .processNameSuffix("sh").version(1)
    }
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) { sh = IShell.Stub.asInterface(b); js("onStatus()") }
        override fun onServiceDisconnected(n: ComponentName) { sh = null; js("onStatus()") }
    }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, r ->
        if (r == PackageManager.PERMISSION_GRANTED) bind()
        js("onStatus()")
    }
    private val binderL = Shizuku.OnBinderReceivedListener { if (granted()) bind(); js("onStatus()") }

    private fun granted() = Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    private fun bind() { if (sh == null) Shizuku.bindUserService(args, conn) }
    private fun js(code: String) = runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Native.parse(if (iniFile.exists()) iniFile.readText() else DEFAULT_INI)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(), "A")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        Shizuku.addRequestPermissionResultListener(permL)
        Shizuku.addBinderReceivedListenerSticky(binderL)
    }

    override fun onDestroy() {
        running = false
        Shizuku.removeRequestPermissionResultListener(permL)
        Shizuku.removeBinderReceivedListener(binderL)
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface fun status(): String = when {
            !Shizuku.pingBinder() -> "Shizuku chưa chạy"
            !granted() -> "Chưa cấp quyền Shizuku"
            sh == null -> "Đang kết nối..."
            else -> "Sẵn sàng"
        }
        @JavascriptInterface fun auth() {
            if (!Shizuku.pingBinder()) return
            if (granted()) bind() else Shizuku.requestPermission(1)
        }
        @JavascriptInterface fun exec(cmd: String) {
            Thread {
                val r = try { sh?.exec(cmd) ?: "Chưa kết nối Shizuku" } catch (e: Exception) { e.message ?: "Lỗi" }
                js("onOut(${JSONObject.quote(r)})")
            }.start()
        }
        @JavascriptInterface fun loadIni(): String = if (iniFile.exists()) iniFile.readText() else DEFAULT_INI
        @JavascriptInterface fun saveIni(t: String) { iniFile.writeText(t); Native.parse(t) }
        @JavascriptInterface fun sens(dpi: Int, base: Int): Int = Native.sens(dpi, base)
        @JavascriptInterface fun run(name: String) {
            if (running) return
            running = true
            Thread {
                val n = Native.repeat(name)
                val script = Native.script(name)
                if (script.isEmpty()) js("onOut('Macro trống hoặc không tồn tại')")
                var i = 0
                while (running && script.isNotEmpty() && (n == 0 || i < n)) {
                    try { sh?.exec(script) } catch (e: Exception) { js("onOut(${JSONObject.quote(e.message ?: "Lỗi")})"); break }
                    i++
                    js("onOut('Vòng $i')")
                }
                running = false
                js("onOut('Đã dừng')")
            }.start()
        }
        @JavascriptInterface fun stop() { running = false }
    }

    companion object {
        const val DEFAULT_INI = "[dpi]\nvalue=420\n\n[macro1]\nrepeat=5\ns1=tap 540 1200 300\ns2=swipe 300 1500 300 800 250 400\ns3=key 4 200\n"
    }
}
