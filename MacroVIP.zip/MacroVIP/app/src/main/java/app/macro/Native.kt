package app.macro

object Native {
    init { System.loadLibrary("macro") }
    external fun parse(iniText: String)
    external fun sens(dpi: Int, base: Int): Int
    external fun script(macro: String): String
    external fun repeat(macro: String): Int
}
