package app.macro

// Chạy trong tiến trình Shizuku (quyền shell)
class ShellService : IShell.Stub() {
    override fun destroy() { System.exit(0) }
    override fun exec(cmd: String): String {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }
}
